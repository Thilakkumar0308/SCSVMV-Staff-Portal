<?php
echo password_hash("scsvmv123*", PASSWORD_BCRYPT);
?>
