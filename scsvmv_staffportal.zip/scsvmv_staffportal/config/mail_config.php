<?php
// Email Configuration
return [
    'smtp_host' => 'smtp.gmail.com',  // Gmail SMTP server
    'smtp_port' => 587,               // TLS port
    'smtp_secure' => 'tls',           // Use TLS
    'smtp_auth' => true,
    'smtp_username' => '112148042@kanchiuniv.ac.in', // University email address
    'smtp_password' => '',    // You'll need to set your password here
    'from_email' => '112148042@kanchiuniv.ac.in',    // University email address
    'from_name' => 'SCSVMV Student Portal',
    'reply_to' => '112148042@kanchiuniv.ac.in',
];
?>